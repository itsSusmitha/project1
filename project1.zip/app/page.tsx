"use client";

import dynamic from "next/dynamic";
import { useEffect, useRef, useState, useCallback } from "react";

/* ─────────────────── DYNAMIC WRAPPER TO PREVENT SSR ─────────────────── */
const HarryPotterGameInner = dynamic(() => Promise.resolve(HarryPotterGameComponent), {
  ssr: false,
});

export default function HarryPotterGame() {
  return <HarryPotterGameInner />;
}

/* ─────────────────────────── TYPES ─────────────────────────── */
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  alpha: number;
}

interface Cloud {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  opacity: number;
}

interface Star {
  x: number;
  y: number;
  size: number;
  twinkle: number;
  speed: number;
}

interface Snitch {
  x: number;
  y: number;
  wingAngle: number;
  sparkles: { x: number; y: number; alpha: number; size: number }[];
  bobOffset: number;
  speed: number;
}

interface SpellOrb {
  x: number;
  y: number;
  spell: string;
  color: string;
  glowColor: string;
  pulseOffset: number;
  speed: number;
}

interface Dementor {
  x: number;
  y: number;
  speed: number;
  floatOffset: number;
  smokeParticles: { x: number; y: number; alpha: number; size: number }[];
  eyeGlow: number;
}

interface Boss {
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  phase: number;
  attackTimer: number;
  floatOffset: number;
  shieldActive: boolean;
  spells: { x: number; y: number; vx: number; vy: number; color: string }[];
}

interface Companion {
  type: "phoenix" | "snake" | "owl" | "badger";
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  floatOffset: number;
  abilityTimer: number;
  glowPhase: number;
  projectiles: { x: number; y: number; vx: number; vy: number; life: number; color: string }[];
  shieldActive: boolean;
  shieldTimer: number;
}

interface CompanionConfig {
  type: "phoenix" | "snake" | "owl" | "badger";
  name: string;
  color: string;
  glowColor: string;
  abilityCooldown: number;
  abilityDesc: string;
}

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  cloakWave: number;
  auraPhase: number;
  bobOffset: number;
}

interface House {
  name: string;
  colors: { primary: string; secondary: string; glow: string };
  characters: string[];
  ability: string;
  abilityDesc: string;
}

type GameState = "houseSelect" | "characterSelect" | "start" | "playing" | "gameover" | "transition" | "victory" | "bossIntro";

/* ──────────────── HOUSE DATA WITH ABILITIES ──────────────── */
const HOUSES: House[] = [
  {
    name: "Gryffindor",
    colors: { primary: "#740001", secondary: "#D3A625", glow: "#FFD700" },
    characters: ["Harry", "Hermione", "Ron", "Neville", "Ginny"],
    ability: "Courage Bonus",
    abilityDesc: "+2 bonus score per snitch",
  },
  {
    name: "Slytherin",
    colors: { primary: "#1A472A", secondary: "#5D5D5D", glow: "#2EE65D" },
    characters: ["Draco", "Pansy", "Blaise", "Crabbe", "Goyle"],
    ability: "Swift Movement",
    abilityDesc: "25% faster flying speed",
  },
  {
    name: "Ravenclaw",
    colors: { primary: "#0E1A40", secondary: "#946B2D", glow: "#5DA5E6" },
    characters: ["Luna", "Cho", "Padma", "Terry", "Michael"],
    ability: "Wisdom Mastery",
    abilityDesc: "Spells last 50% longer",
  },
  {
    name: "Hufflepuff",
    colors: { primary: "#ECB939", secondary: "#372E29", glow: "#FFD700" },
    characters: ["Cedric", "Susan", "Hannah", "Ernie", "Justin"],
    ability: "Loyal Heart",
    abilityDesc: "Start with +1 extra life",
  },
];

/* ──────────────── LEVEL DEFINITIONS ──────────────── */
const LEVELS = [
  { name: "Training Grounds", scoreThreshold: 0, speedMult: 1, spawnMult: 1, bgTint: "rgba(0,0,0,0)" },
  { name: "Quidditch Pitch", scoreThreshold: 30, speedMult: 1.3, spawnMult: 1.2, bgTint: "rgba(0,30,60,0.15)" },
  { name: "Forbidden Forest", scoreThreshold: 60, speedMult: 1.6, spawnMult: 1.5, bgTint: "rgba(0,50,20,0.2)" },
  { name: "Dark Storm", scoreThreshold: 100, speedMult: 2, spawnMult: 2, bgTint: "rgba(20,0,40,0.3)" },
  { name: "Final Battle", scoreThreshold: 150, speedMult: 2.5, spawnMult: 0.5, bgTint: "rgba(40,0,20,0.4)" },
];

/* ──────────────── SPELL DEFINITIONS ──────────────── */
const SPELLS = [
  { name: "Expecto Patronum", color: "#00BFFF", glowColor: "#00BFFF" },
  { name: "Lumos", color: "#FFD700", glowColor: "#FFD700" },
  { name: "Expelliarmus", color: "#FF4500", glowColor: "#FF6347" },
  { name: "Stupefy", color: "#FF00FF", glowColor: "#FF69B4" },
];

/* ──────────────── COMPANION DEFINITIONS ──────────────── */
const COMPANION_CONFIGS: Record<string, CompanionConfig> = {
  Gryffindor: {
    type: "phoenix",
    name: "Fire Phoenix",
    color: "#FF6600",
    glowColor: "#FF4400",
    abilityCooldown: 180, // 3 seconds at 60fps
    abilityDesc: "Shoots fire at enemies",
  },
  Slytherin: {
    type: "snake",
    name: "Shadow Snake",
    color: "#00FF66",
    glowColor: "#00CC44",
    abilityCooldown: 240, // 4 seconds
    abilityDesc: "Poisons and slows enemies",
  },
  Ravenclaw: {
    type: "owl",
    name: "Mystic Owl",
    color: "#6699FF",
    glowColor: "#4477FF",
    abilityCooldown: 300, // 5 seconds - passive bonus
    abilityDesc: "+10% score, reveals power-ups",
  },
  Hufflepuff: {
    type: "badger",
    name: "Guardian Badger",
    color: "#FFCC00",
    glowColor: "#FFAA00",
    abilityCooldown: 600, // 10 seconds
    abilityDesc: "Generates protective shield",
  },
};

function HarryPotterGameComponent() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bgImageRef = useRef<HTMLImageElement | null>(null);
  const startBgImageRef = useRef<HTMLImageElement | null>(null);

  /* Game state refs (mutable in animation loop) */
  const gameStateRef = useRef<GameState>("houseSelect");
  const playerRef = useRef<Player>({
    x: 200, y: 300, vx: 0, vy: 0,
    cloakWave: 0, auraPhase: 0, bobOffset: 0,
  });
  const scoreRef = useRef(0);
  const livesRef = useRef(3);
  const levelRef = useRef(0);
  const wizardNameRef = useRef("Wizard");
  const selectedHouseRef = useRef<House | null>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  const touchControlsRef = useRef<{ up: boolean; down: boolean; left: boolean; right: boolean }>({ up: false, down: false, left: false, right: false });
  const snitchesRef = useRef<Snitch[]>([]);
  const spellOrbsRef = useRef<SpellOrb[]>([]);
  const dementorsRef = useRef<Dementor[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const cloudsRef = useRef<Cloud[]>([]);
  const starsRef = useRef<Star[]>([]);
  const activeSpellRef = useRef<string>("");
  const spellTimerRef = useRef(0);
  const spellPopupRef = useRef<{ text: string; timer: number } | null>(null);
  const levelPopupRef = useRef<{ text: string; timer: number } | null>(null);
  const frameCountRef = useRef(0);
  const difficultyRef = useRef(1);
  const transitionAlphaRef = useRef(0);
  const gameOverFadeRef = useRef(0);
  const spawnTimerRef = useRef({ snitch: 0, spell: 0, dementor: 0 });
  const invincibleRef = useRef(0);
  const animFrameRef = useRef(0);
  const lumosPulseRef = useRef(0);
  const patronusWaveRef = useRef(0);
  const screenShakeRef = useRef(0);
  const bossRef = useRef<Boss | null>(null);
  const bossIntroTimerRef = useRef(0);
  const companionRef = useRef<Companion | null>(null);
  const companionPopupRef = useRef<{ text: string; timer: number } | null>(null);
  const poisonedEnemiesRef = useRef<Set<Dementor>>(new Set());

  /* React state for overlay UI */
  const [uiState, setUiState] = useState<GameState>("houseSelect");
  const [selectedHouse, setSelectedHouse] = useState<House | null>(null);
  const [selectedCharacter, setSelectedCharacter] = useState<string>("");
  const [finalScore, setFinalScore] = useState(0);
  const [finalName, setFinalName] = useState("");
  const [hoveredHouse, setHoveredHouse] = useState<string | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(0);

  /* ──────────── HELPERS ──────────── */
  const rand = (min: number, max: number) => Math.random() * (max - min) + min;

  const distance = (x1: number, y1: number, x2: number, y2: number) =>
    Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);

  const spawnParticles = (
    x: number, y: number, count: number, color: string, spread = 3
  ) => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x, y,
        vx: rand(-spread, spread),
        vy: rand(-spread, spread),
        life: rand(20, 60),
        maxLife: 60,
        size: rand(1, 4),
        color,
        alpha: 1,
      });
    }
  };

  /* House ability helpers */
  const getSnitchBonus = () => {
    const house = selectedHouseRef.current;
    let base = 15;
    if (house?.name === "Gryffindor") base = 17; // 15 + 2 bonus
    // Ravenclaw owl gives +10% score
    if (house?.name === "Ravenclaw") base = Math.floor(base * 1.1);
    return base;
  };

  const getSpeedMultiplier = () => {
    const house = selectedHouseRef.current;
    if (house?.name === "Slytherin") return 1.25;
    return 1;
  };

  const getSpellDurationMultiplier = () => {
    const house = selectedHouseRef.current;
    if (house?.name === "Ravenclaw") return 1.5;
    return 1;
  };

  const getStartingLives = () => {
    const house = selectedHouseRef.current;
    if (house?.name === "Hufflepuff") return 4;
    return 3;
  };

  /* ──────────── INIT FUNCTIONS ──────────── */
  const initClouds = useCallback((w: number, h: number) => {
    cloudsRef.current = [];
    for (let i = 0; i < 8; i++) {
      cloudsRef.current.push({
        x: rand(0, w),
        y: rand(0, h * 0.5),
        width: rand(120, 300),
        height: rand(40, 80),
        speed: rand(0.2, 0.8),
        opacity: rand(0.08, 0.25),
      });
    }
  }, []);

  const initStars = useCallback((w: number, h: number) => {
    starsRef.current = [];
    for (let i = 0; i < 100; i++) {
      starsRef.current.push({
        x: rand(0, w),
        y: rand(0, h * 0.6),
        size: rand(0.5, 2.5),
        twinkle: rand(0, Math.PI * 2),
        speed: rand(0.01, 0.05),
      });
    }
  }, []);

  const resetGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const w = canvas.width;
    const h = canvas.height;

    playerRef.current = {
      x: 200, y: h / 2, vx: 0, vy: 0,
      cloakWave: 0, auraPhase: 0, bobOffset: 0,
    };
    scoreRef.current = 0;
    livesRef.current = getStartingLives();
    levelRef.current = 0;
    snitchesRef.current = [];
    spellOrbsRef.current = [];
    dementorsRef.current = [];
    particlesRef.current = [];
    activeSpellRef.current = "";
    spellTimerRef.current = 0;
    spellPopupRef.current = null;
    levelPopupRef.current = null;
    frameCountRef.current = 0;
    difficultyRef.current = 1;
    transitionAlphaRef.current = 0;
    gameOverFadeRef.current = 0;
    invincibleRef.current = 0;
    lumosPulseRef.current = 0;
    patronusWaveRef.current = 0;
    screenShakeRef.current = 0;
    bossRef.current = null;
    bossIntroTimerRef.current = 0;
    spawnTimerRef.current = { snitch: 0, spell: 0, dementor: 0 };
    poisonedEnemiesRef.current = new Set();
    companionPopupRef.current = null;
    
    // Initialize companion based on house
    const house = selectedHouseRef.current;
    if (house && COMPANION_CONFIGS[house.name]) {
      const config = COMPANION_CONFIGS[house.name];
      companionRef.current = {
        type: config.type,
        x: 100,
        y: h / 2 - 40,
        targetX: 100,
        targetY: h / 2 - 40,
        floatOffset: 0,
        abilityTimer: 0,
        glowPhase: 0,
        projectiles: [],
        shieldActive: false,
        shieldTimer: 0,
      };
    }
    
    setCurrentLevel(0);
    initClouds(w, h);
    initStars(w, h);
  }, [initClouds, initStars]);

  /* ───────────── DRAWING HELPERS ───────────── */

  /** Draw a detailed wizard on broomstick with house colors */
  const drawWizard = (ctx: CanvasRenderingContext2D, p: Player, t: number) => {
    ctx.save();
    const bobY = Math.sin(p.bobOffset) * 4;
    ctx.translate(p.x, p.y + bobY);

    const house = selectedHouseRef.current;
    const auraColor = house ? house.colors.glow : "#64B4FF";
    const robeColor = house ? house.colors.primary : "#1a1a3e";
    const accentColor = house ? house.colors.secondary : "#DAA520";

    /* Magical aura with house color */
    const auraSize = 45 + Math.sin(p.auraPhase) * 8;
    const auraGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, auraSize);
    auraGrad.addColorStop(0, auraColor + "40");
    auraGrad.addColorStop(0.5, auraColor + "15");
    auraGrad.addColorStop(1, auraColor + "00");
    ctx.fillStyle = auraGrad;
    ctx.beginPath();
    ctx.arc(0, 0, auraSize, 0, Math.PI * 2);
    ctx.fill();

    /* Broomstick */
    ctx.strokeStyle = "#8B5E3C";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-35, 10);
    ctx.lineTo(40, 10);
    ctx.stroke();
    // Broom bristles
    ctx.strokeStyle = "#A0723C";
    ctx.lineWidth = 2;
    for (let i = 0; i < 8; i++) {
      const angle = (i - 3.5) * 0.15;
      const waveOffset = Math.sin(t * 3 + i) * 2;
      ctx.beginPath();
      ctx.moveTo(38, 10);
      ctx.lineTo(55 + waveOffset, 10 + Math.sin(angle) * 12 + (i - 3.5) * 2);
      ctx.stroke();
    }

    /* Body / Robe with house color */
    ctx.fillStyle = robeColor;
    ctx.beginPath();
    ctx.moveTo(-8, -8);
    ctx.lineTo(8, -8);
    ctx.lineTo(12, 8);
    ctx.lineTo(-12, 8);
    ctx.closePath();
    ctx.fill();

    /* Cloak flowing */
    const cloakWave = Math.sin(p.cloakWave) * 6;
    ctx.fillStyle = robeColor;
    ctx.beginPath();
    ctx.moveTo(-10, -5);
    ctx.quadraticCurveTo(-25, 5 + cloakWave, -20, 18 + cloakWave);
    ctx.lineTo(-8, 8);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-12, 0);
    ctx.quadraticCurveTo(-30, 10 + cloakWave * 0.7, -25, 22 + cloakWave * 0.5);
    ctx.lineTo(-10, 8);
    ctx.closePath();
    ctx.fill();

    /* Head */
    ctx.fillStyle = "#F5D5B8";
    ctx.beginPath();
    ctx.arc(0, -16, 9, 0, Math.PI * 2);
    ctx.fill();

    /* Wizard hat with house color */
    ctx.fillStyle = robeColor;
    ctx.beginPath();
    ctx.moveTo(-12, -19);
    ctx.lineTo(12, -19);
    ctx.lineTo(3 + Math.sin(t * 2) * 2, -40);
    ctx.closePath();
    ctx.fill();
    // Hat brim
    ctx.fillStyle = accentColor;
    ctx.beginPath();
    ctx.ellipse(0, -19, 15, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    /* Hair */
    ctx.fillStyle = "#1a0a00";
    ctx.beginPath();
    ctx.arc(0, -18, 9, -Math.PI, -0.2);
    ctx.fill();

    /* Glasses */
    ctx.strokeStyle = "#777";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(-4, -16, 3, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(4, -16, 3, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-1, -16);
    ctx.lineTo(1, -16);
    ctx.stroke();

    /* Scarf with house colors */
    ctx.fillStyle = robeColor;
    ctx.fillRect(-4, -9, 8, 4);
    ctx.fillStyle = accentColor;
    ctx.fillRect(-4, -7, 8, 1);

    /* Wand */
    ctx.strokeStyle = "#C4A265";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(10, -5);
    ctx.lineTo(25, -18);
    ctx.stroke();
    // Wand tip spark
    const sparkSize = 2 + Math.sin(t * 8) * 1.5;
    ctx.shadowColor = auraColor;
    ctx.shadowBlur = 10;
    ctx.fillStyle = auraColor;
    ctx.beginPath();
    ctx.arc(25, -18, sparkSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    /* Hands */
    ctx.fillStyle = "#F5D5B8";
    ctx.beginPath();
    ctx.arc(10, -4, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-5, 6, 3, 0, Math.PI * 2);
    ctx.fill();

    /* Legs on broom */
    ctx.fillStyle = robeColor;
    ctx.fillRect(-5, 8, 4, 8);
    ctx.fillRect(3, 8, 4, 8);
    /* Shoes */
    ctx.fillStyle = "#2a2a2a";
    ctx.fillRect(-6, 14, 6, 3);
    ctx.fillRect(2, 14, 6, 3);

    ctx.restore();
  };

  /** Draw golden snitch */
  const drawSnitch = (ctx: CanvasRenderingContext2D, s: Snitch, t: number) => {
    ctx.save();
    const bobY = Math.sin(s.bobOffset + t * 3) * 5;
    ctx.translate(s.x, s.y + bobY);

    /* Sparkle trail */
    s.sparkles.forEach((sp) => {
      ctx.globalAlpha = sp.alpha;
      ctx.fillStyle = "#FFD700";
      ctx.shadowColor = "#FFD700";
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(sp.x - s.x, sp.y - s.y + bobY, sp.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;

    /* Wings */
    const wingAngle = Math.sin(s.wingAngle) * 0.5;
    ctx.save();
    ctx.translate(0, -2);
    // Left wing
    ctx.save();
    ctx.rotate(-0.3 + wingAngle);
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(-15, -15, -8, -25);
    ctx.quadraticCurveTo(-2, -15, 0, 0);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    // Right wing
    ctx.save();
    ctx.rotate(0.3 - wingAngle);
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(15, -15, 8, -25);
    ctx.quadraticCurveTo(2, -15, 0, 0);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    ctx.restore();

    /* Golden ball */
    ctx.shadowColor = "#FFD700";
    ctx.shadowBlur = 20;
    const grad = ctx.createRadialGradient(-2, -2, 2, 0, 0, 10);
    grad.addColorStop(0, "#FFF8DC");
    grad.addColorStop(0.4, "#FFD700");
    grad.addColorStop(1, "#B8860B");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    /* Highlight */
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.beginPath();
    ctx.arc(-3, -3, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  };

  /** Draw spell orb */
  const drawSpellOrb = (ctx: CanvasRenderingContext2D, orb: SpellOrb, t: number) => {
    ctx.save();
    const bobY = Math.sin(orb.pulseOffset + t * 2) * 6;
    ctx.translate(orb.x, orb.y + bobY);

    const pulseSize = 14 + Math.sin(t * 4 + orb.pulseOffset) * 3;

    /* Outer glow */
    ctx.shadowColor = orb.glowColor;
    ctx.shadowBlur = 25;
    const outerGrad = ctx.createRadialGradient(0, 0, 5, 0, 0, pulseSize + 8);
    outerGrad.addColorStop(0, orb.color + "88");
    outerGrad.addColorStop(1, orb.color + "00");
    ctx.fillStyle = outerGrad;
    ctx.beginPath();
    ctx.arc(0, 0, pulseSize + 8, 0, Math.PI * 2);
    ctx.fill();

    /* Core */
    const coreGrad = ctx.createRadialGradient(-2, -2, 2, 0, 0, pulseSize);
    coreGrad.addColorStop(0, "#FFFFFF");
    coreGrad.addColorStop(0.3, orb.color);
    coreGrad.addColorStop(1, orb.color + "66");
    ctx.fillStyle = coreGrad;
    ctx.beginPath();
    ctx.arc(0, 0, pulseSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    /* Inner sparkles */
    for (let i = 0; i < 4; i++) {
      const angle = t * 3 + (i * Math.PI) / 2;
      const dist = pulseSize * 0.5;
      ctx.fillStyle = "rgba(255,255,255,0.8)";
      ctx.beginPath();
      ctx.arc(Math.cos(angle) * dist, Math.sin(angle) * dist, 1.5, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  };

  /** Draw dementor */
  const drawDementor = (ctx: CanvasRenderingContext2D, d: Dementor, t: number) => {
    ctx.save();
    const bobY = Math.sin(d.floatOffset + t * 1.5) * 8;
    ctx.translate(d.x, d.y + bobY);

    /* Smoke particles */
    d.smokeParticles.forEach((sp) => {
      ctx.globalAlpha = sp.alpha * 0.5;
      ctx.fillStyle = "#1a0a2e";
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, sp.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;

    /* Dark aura */
    const auraGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, 50);
    auraGrad.addColorStop(0, "rgba(20,0,40,0.4)");
    auraGrad.addColorStop(1, "rgba(20,0,40,0)");
    ctx.fillStyle = auraGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 50, 0, Math.PI * 2);
    ctx.fill();

    /* Tattered cloak body */
    ctx.fillStyle = "#0d0d1a";
    ctx.beginPath();
    ctx.moveTo(-15, -25);
    ctx.quadraticCurveTo(-20, 0, -18, 30);
    const wave1 = Math.sin(t * 2 + d.floatOffset) * 4;
    const wave2 = Math.sin(t * 2.5 + d.floatOffset + 1) * 3;
    ctx.quadraticCurveTo(-10, 35 + wave1, 0, 38 + wave2);
    ctx.quadraticCurveTo(10, 35 + wave1, 18, 30);
    ctx.quadraticCurveTo(20, 0, 15, -25);
    ctx.closePath();
    ctx.fill();

    /* Inner cloak shading */
    ctx.fillStyle = "#15152e";
    ctx.beginPath();
    ctx.moveTo(-10, -15);
    ctx.quadraticCurveTo(-12, 5, -10, 25);
    ctx.lineTo(10, 25);
    ctx.quadraticCurveTo(12, 5, 10, -15);
    ctx.closePath();
    ctx.fill();

    /* Hood */
    ctx.fillStyle = "#0a0a18";
    ctx.beginPath();
    ctx.moveTo(-18, -20);
    ctx.quadraticCurveTo(0, -42, 18, -20);
    ctx.quadraticCurveTo(0, -15, -18, -20);
    ctx.fill();

    /* Face darkness */
    ctx.fillStyle = "#050510";
    ctx.beginPath();
    ctx.ellipse(0, -22, 8, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    /* Glowing eyes */
    const eyeGlow = 0.5 + Math.sin(d.eyeGlow) * 0.3;
    ctx.shadowColor = "#4488ff";
    ctx.shadowBlur = 12;
    ctx.fillStyle = `rgba(80, 140, 255, ${eyeGlow})`;
    ctx.beginPath();
    ctx.ellipse(-4, -23, 2.5, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(4, -23, 2.5, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    /* Skeletal hands reaching */
    ctx.strokeStyle = "#2a2a4a";
    ctx.lineWidth = 2;
    const handWave = Math.sin(t * 2) * 5;
    // Left hand
    ctx.beginPath();
    ctx.moveTo(-15, 5);
    ctx.quadraticCurveTo(-28, 0 + handWave, -32, -8 + handWave);
    ctx.stroke();
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(-32, -8 + handWave);
      ctx.lineTo(-36 - i * 2, -12 + handWave + i * 3);
      ctx.stroke();
    }
    // Right hand
    ctx.beginPath();
    ctx.moveTo(15, 5);
    ctx.quadraticCurveTo(28, 0 + handWave, 32, -8 + handWave);
    ctx.stroke();
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(32, -8 + handWave);
      ctx.lineTo(36 + i * 2, -12 + handWave + i * 3);
      ctx.stroke();
    }

    /* Tattered cloak edges */
    ctx.strokeStyle = "#0a0a18";
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
      const bx = -12 + i * 6;
      const by = 30 + Math.sin(t * 2 + i) * 4;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(bx + rand(-3, 3), by + rand(5, 15));
      ctx.stroke();
    }

    ctx.restore();
  };

  /** Draw Dark Lord Boss */
  const drawBoss = (ctx: CanvasRenderingContext2D, boss: Boss, t: number) => {
    ctx.save();
    const bobY = Math.sin(boss.floatOffset) * 10;
    ctx.translate(boss.x, boss.y + bobY);

    // Dark aura
    const auraSize = 120 + Math.sin(t * 2) * 20;
    const auraGrad = ctx.createRadialGradient(0, 0, 30, 0, 0, auraSize);
    auraGrad.addColorStop(0, "rgba(80,0,120,0.5)");
    auraGrad.addColorStop(0.5, "rgba(40,0,60,0.3)");
    auraGrad.addColorStop(1, "rgba(20,0,40,0)");
    ctx.fillStyle = auraGrad;
    ctx.beginPath();
    ctx.arc(0, 0, auraSize, 0, Math.PI * 2);
    ctx.fill();

    // Shield if active
    if (boss.shieldActive) {
      ctx.strokeStyle = `rgba(150,50,200,${0.5 + Math.sin(t * 4) * 0.2})`;
      ctx.lineWidth = 4;
      ctx.shadowColor = "#9932CC";
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.arc(0, 0, 80, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // Giant dark robes
    ctx.fillStyle = "#0a0510";
    ctx.beginPath();
    ctx.moveTo(-50, -40);
    ctx.quadraticCurveTo(-70, 20, -60, 80);
    const wv = Math.sin(t * 1.5) * 8;
    ctx.quadraticCurveTo(-30, 100 + wv, 0, 90 + wv);
    ctx.quadraticCurveTo(30, 100 + wv, 60, 80);
    ctx.quadraticCurveTo(70, 20, 50, -40);
    ctx.closePath();
    ctx.fill();

    // Inner robe shading
    ctx.fillStyle = "#150520";
    ctx.beginPath();
    ctx.moveTo(-35, -20);
    ctx.quadraticCurveTo(-40, 20, -35, 60);
    ctx.lineTo(35, 60);
    ctx.quadraticCurveTo(40, 20, 35, -20);
    ctx.closePath();
    ctx.fill();

    // Hood
    ctx.fillStyle = "#080310";
    ctx.beginPath();
    ctx.moveTo(-50, -35);
    ctx.quadraticCurveTo(0, -100, 50, -35);
    ctx.quadraticCurveTo(0, -25, -50, -35);
    ctx.fill();

    // Face (pale/skull-like)
    ctx.fillStyle = "#dde8ee";
    ctx.beginPath();
    ctx.ellipse(0, -45, 20, 25, 0, 0, Math.PI * 2);
    ctx.fill();

    // Red eyes
    ctx.shadowColor = "#FF0000";
    ctx.shadowBlur = 15;
    ctx.fillStyle = "#FF0000";
    ctx.beginPath();
    ctx.ellipse(-8, -50, 4, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(8, -50, 4, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Nose slits
    ctx.fillStyle = "#080310";
    ctx.beginPath();
    ctx.ellipse(-3, -40, 2, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(3, -40, 2, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Wand
    ctx.strokeStyle = "#3a3a3a";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(40, 0);
    ctx.lineTo(80, -30);
    ctx.stroke();

    // Wand glow
    ctx.shadowColor = "#00FF00";
    ctx.shadowBlur = 20;
    ctx.fillStyle = "#00FF00";
    ctx.beginPath();
    ctx.arc(80, -30, 6 + Math.sin(t * 6) * 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.restore();

    // Health bar
    const barWidth = 300;
    const barHeight = 20;
    const barX = (canvasRef.current?.width || 800) / 2 - barWidth / 2;
    const barY = 30;
    
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(barX - 5, barY - 5, barWidth + 10, barHeight + 10);
    
    ctx.fillStyle = "#333";
    ctx.fillRect(barX, barY, barWidth, barHeight);
    
    const healthPercent = boss.health / boss.maxHealth;
    const healthColor = healthPercent > 0.5 ? "#4CAF50" : healthPercent > 0.25 ? "#FF9800" : "#F44336";
    ctx.fillStyle = healthColor;
    ctx.fillRect(barX, barY, barWidth * healthPercent, barHeight);
    
    ctx.strokeStyle = "#FFD700";
    ctx.lineWidth = 2;
    ctx.strokeRect(barX, barY, barWidth, barHeight);

    ctx.fillStyle = "#FFD700";
    ctx.font = "bold 14px Georgia";
    ctx.textAlign = "center";
    ctx.fillText("DARK LORD", (canvasRef.current?.width || 800) / 2, barY + 45);
  };

  /** Draw magical companion */
  const drawCompanion = (ctx: CanvasRenderingContext2D, companion: Companion, t: number) => {
    const house = selectedHouseRef.current;
    if (!house) return;
    const config = COMPANION_CONFIGS[house.name];
    if (!config) return;

    ctx.save();
    const bobY = Math.sin(companion.floatOffset) * 6;
    ctx.translate(companion.x, companion.y + bobY);

    // Glow aura
    const glowSize = 25 + Math.sin(companion.glowPhase) * 5;
    const glowGrad = ctx.createRadialGradient(0, 0, 5, 0, 0, glowSize);
    glowGrad.addColorStop(0, config.glowColor + "60");
    glowGrad.addColorStop(0.5, config.glowColor + "30");
    glowGrad.addColorStop(1, config.glowColor + "00");
    ctx.fillStyle = glowGrad;
    ctx.beginPath();
    ctx.arc(0, 0, glowSize, 0, Math.PI * 2);
    ctx.fill();

    // Draw based on type
    if (companion.type === "phoenix") {
      // Fire Phoenix - orange/red bird
      ctx.shadowColor = "#FF4400";
      ctx.shadowBlur = 15;
      
      // Body
      const bodyGrad = ctx.createRadialGradient(-2, 0, 2, 0, 0, 12);
      bodyGrad.addColorStop(0, "#FFDD00");
      bodyGrad.addColorStop(0.5, "#FF6600");
      bodyGrad.addColorStop(1, "#FF2200");
      ctx.fillStyle = bodyGrad;
      ctx.beginPath();
      ctx.ellipse(0, 0, 12, 8, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Head
      ctx.fillStyle = "#FF8800";
      ctx.beginPath();
      ctx.arc(10, -3, 6, 0, Math.PI * 2);
      ctx.fill();
      
      // Beak
      ctx.fillStyle = "#FFCC00";
      ctx.beginPath();
      ctx.moveTo(15, -3);
      ctx.lineTo(20, -2);
      ctx.lineTo(15, -1);
      ctx.closePath();
      ctx.fill();
      
      // Eye
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.arc(12, -4, 1.5, 0, Math.PI * 2);
      ctx.fill();
      
      // Wings (animated)
      const wingAngle = Math.sin(t * 8) * 0.4;
      ctx.save();
      ctx.rotate(wingAngle - 0.3);
      ctx.fillStyle = "#FF4400";
      ctx.beginPath();
      ctx.moveTo(0, -2);
      ctx.quadraticCurveTo(-10, -18, -5, -22);
      ctx.quadraticCurveTo(0, -15, 0, -2);
      ctx.fill();
      ctx.restore();
      
      ctx.save();
      ctx.rotate(-wingAngle + 0.3);
      ctx.fillStyle = "#FF4400";
      ctx.beginPath();
      ctx.moveTo(0, 2);
      ctx.quadraticCurveTo(-10, 18, -5, 22);
      ctx.quadraticCurveTo(0, 15, 0, 2);
      ctx.fill();
      ctx.restore();
      
      // Tail flames
      for (let i = 0; i < 3; i++) {
        const flameOffset = Math.sin(t * 6 + i * 2) * 3;
        ctx.fillStyle = i === 1 ? "#FFDD00" : "#FF4400";
        ctx.beginPath();
        ctx.moveTo(-10, 0);
        ctx.quadraticCurveTo(-18 + flameOffset, i - 1, -22 - i * 3, (i - 1) * 4 + flameOffset);
        ctx.quadraticCurveTo(-15, i - 1, -10, 0);
        ctx.fill();
      }
      ctx.shadowBlur = 0;
      
    } else if (companion.type === "snake") {
      // Shadow Snake - green serpent
      ctx.shadowColor = "#00FF44";
      ctx.shadowBlur = 10;
      
      // Coiled body
      const snakeWave = Math.sin(t * 4) * 3;
      ctx.strokeStyle = "#00AA44";
      ctx.lineWidth = 6;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-15, snakeWave);
      ctx.quadraticCurveTo(-5, -8 + snakeWave, 5, snakeWave);
      ctx.quadraticCurveTo(12, 6 + snakeWave, 15, snakeWave);
      ctx.stroke();
      
      // Body highlight
      ctx.strokeStyle = "#00FF66";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-14, snakeWave - 1);
      ctx.quadraticCurveTo(-5, -9 + snakeWave, 5, snakeWave - 1);
      ctx.stroke();
      
      // Head
      ctx.fillStyle = "#00CC44";
      ctx.beginPath();
      ctx.ellipse(15, snakeWave, 6, 5, 0.2, 0, Math.PI * 2);
      ctx.fill();
      
      // Eyes
      ctx.fillStyle = "#FFFF00";
      ctx.beginPath();
      ctx.ellipse(17, snakeWave - 2, 2, 1.5, 0.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.ellipse(17.5, snakeWave - 2, 0.8, 1.2, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Tongue
      const tongueWave = Math.sin(t * 10) * 2;
      ctx.strokeStyle = "#FF4466";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(20, snakeWave);
      ctx.lineTo(25 + tongueWave, snakeWave - 1);
      ctx.moveTo(23, snakeWave);
      ctx.lineTo(25 + tongueWave, snakeWave + 1);
      ctx.stroke();
      ctx.shadowBlur = 0;
      
    } else if (companion.type === "owl") {
      // Mystic Owl - blue wise owl
      ctx.shadowColor = "#4477FF";
      ctx.shadowBlur = 12;
      
      // Body
      ctx.fillStyle = "#334488";
      ctx.beginPath();
      ctx.ellipse(0, 3, 10, 12, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Chest feathers
      ctx.fillStyle = "#5577AA";
      ctx.beginPath();
      ctx.ellipse(0, 6, 6, 8, 0, 0, Math.PI);
      ctx.fill();
      
      // Head
      ctx.fillStyle = "#445599";
      ctx.beginPath();
      ctx.arc(0, -8, 9, 0, Math.PI * 2);
      ctx.fill();
      
      // Ear tufts
      ctx.fillStyle = "#334488";
      ctx.beginPath();
      ctx.moveTo(-7, -12);
      ctx.lineTo(-10, -20);
      ctx.lineTo(-4, -14);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(7, -12);
      ctx.lineTo(10, -20);
      ctx.lineTo(4, -14);
      ctx.closePath();
      ctx.fill();
      
      // Eyes (large and wise)
      ctx.fillStyle = "#FFDD00";
      ctx.beginPath();
      ctx.arc(-4, -8, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(4, -8, 4, 0, Math.PI * 2);
      ctx.fill();
      
      // Pupils (blink occasionally)
      const blink = Math.sin(t * 0.5) > 0.95 ? 0.5 : 1;
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.ellipse(-4, -8, 2, 2 * blink, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(4, -8, 2, 2 * blink, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Beak
      ctx.fillStyle = "#FFAA44";
      ctx.beginPath();
      ctx.moveTo(0, -5);
      ctx.lineTo(-2, -2);
      ctx.lineTo(2, -2);
      ctx.closePath();
      ctx.fill();
      
      // Wings (animated)
      const wingFlap = Math.sin(t * 5) * 0.3;
      ctx.save();
      ctx.rotate(-wingFlap);
      ctx.fillStyle = "#3355AA";
      ctx.beginPath();
      ctx.moveTo(-8, 0);
      ctx.quadraticCurveTo(-20, -5, -18, 8);
      ctx.quadraticCurveTo(-12, 10, -8, 5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      
      ctx.save();
      ctx.rotate(wingFlap);
      ctx.fillStyle = "#3355AA";
      ctx.beginPath();
      ctx.moveTo(8, 0);
      ctx.quadraticCurveTo(20, -5, 18, 8);
      ctx.quadraticCurveTo(12, 10, 8, 5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      ctx.shadowBlur = 0;
      
    } else if (companion.type === "badger") {
      // Guardian Badger - yellow/black badger
      ctx.shadowColor = "#FFAA00";
      ctx.shadowBlur = 10;
      
      // Body
      ctx.fillStyle = "#3a3a3a";
      ctx.beginPath();
      ctx.ellipse(0, 2, 14, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Head
      ctx.fillStyle = "#4a4a4a";
      ctx.beginPath();
      ctx.ellipse(12, -2, 8, 7, 0.2, 0, Math.PI * 2);
      ctx.fill();
      
      // White face stripe
      ctx.fillStyle = "#FFFFFF";
      ctx.beginPath();
      ctx.moveTo(10, -8);
      ctx.lineTo(12, -8);
      ctx.lineTo(18, 2);
      ctx.lineTo(16, 3);
      ctx.closePath();
      ctx.fill();
      
      // Black face stripes
      ctx.fillStyle = "#1a1a1a";
      ctx.beginPath();
      ctx.moveTo(8, -6);
      ctx.lineTo(10, -7);
      ctx.lineTo(14, 0);
      ctx.lineTo(12, 1);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(14, -7);
      ctx.lineTo(16, -6);
      ctx.lineTo(20, 1);
      ctx.lineTo(18, 2);
      ctx.closePath();
      ctx.fill();
      
      // Ears
      ctx.fillStyle = "#3a3a3a";
      ctx.beginPath();
      ctx.arc(8, -7, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(16, -7, 3, 0, Math.PI * 2);
      ctx.fill();
      
      // Eyes
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.arc(10, -3, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(16, -3, 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Nose
      ctx.fillStyle = "#1a1a1a";
      ctx.beginPath();
      ctx.ellipse(19, 0, 2, 1.5, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Legs (short animated)
      const legOffset = Math.sin(t * 6) * 2;
      ctx.fillStyle = "#3a3a3a";
      ctx.fillRect(-8, 8 + legOffset, 4, 6);
      ctx.fillRect(-2, 8 - legOffset, 4, 6);
      ctx.fillRect(4, 8 + legOffset, 4, 6);
      ctx.fillRect(10, 8 - legOffset, 4, 6);
      ctx.shadowBlur = 0;
    }

    ctx.restore();

    // Draw shield if active (Hufflepuff)
    if (companion.shieldActive) {
      const p = playerRef.current;
      const shieldPulse = 0.5 + Math.sin(t * 4) * 0.2;
      ctx.strokeStyle = `rgba(255,204,0,${shieldPulse})`;
      ctx.lineWidth = 3;
      ctx.shadowColor = "#FFCC00";
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 50, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // Draw projectiles
    companion.projectiles.forEach((proj) => {
      ctx.shadowColor = config.glowColor;
      ctx.shadowBlur = 10;
      ctx.fillStyle = proj.color;
      ctx.beginPath();
      ctx.arc(proj.x, proj.y, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  };

  /* ───────────── MAIN GAME LOOP ───────────── */
  const gameLoop = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const W = canvas.width;
    const H = canvas.height;
    const state = gameStateRef.current;
    const t = frameCountRef.current * 0.016;
    frameCountRef.current++;

    // Apply screen shake
    if (screenShakeRef.current > 0) {
      ctx.save();
      const shakeX = (Math.random() - 0.5) * screenShakeRef.current;
      const shakeY = (Math.random() - 0.5) * screenShakeRef.current;
      ctx.translate(shakeX, shakeY);
      screenShakeRef.current *= 0.9;
      if (screenShakeRef.current < 0.5) screenShakeRef.current = 0;
    }

    ctx.clearRect(0, 0, W, H);

    /* ═══════════ HOUSE SELECT / CHARACTER SELECT / START SCREEN ═══════════ */
    if (state === "houseSelect" || state === "characterSelect" || state === "start") {
      if (startBgImageRef.current && startBgImageRef.current.complete) {
        ctx.drawImage(startBgImageRef.current, 0, 0, W, H);
      } else {
        ctx.fillStyle = "#0a0a1a";
        ctx.fillRect(0, 0, W, H);
      }

      ctx.fillStyle = "rgba(5,5,20,0.5)";
      ctx.fillRect(0, 0, W, H);

      for (let i = 0; i < 5; i++) {
        const fogX = ((t * 20 + i * 250) % (W + 400)) - 200;
        const fogY = H * 0.6 + Math.sin(t + i * 1.5) * 40;
        const fogGrad = ctx.createRadialGradient(fogX, fogY, 10, fogX, fogY, 150);
        fogGrad.addColorStop(0, "rgba(100,120,180,0.06)");
        fogGrad.addColorStop(1, "rgba(100,120,180,0)");
        ctx.fillStyle = fogGrad;
        ctx.beginPath();
        ctx.arc(fogX, fogY, 150, 0, Math.PI * 2);
        ctx.fill();
      }

      for (let i = 0; i < 30; i++) {
        const px = (Math.sin(t * 0.3 + i * 2.1) * 0.5 + 0.5) * W;
        const py = (Math.cos(t * 0.2 + i * 1.7) * 0.5 + 0.5) * H;
        const alpha = 0.2 + Math.sin(t * 2 + i) * 0.15;
        ctx.fillStyle = `rgba(255,215,0,${alpha})`;
        ctx.beginPath();
        ctx.arc(px, py, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      if (screenShakeRef.current > 0) ctx.restore();
      animFrameRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    /* ═══════════ BOSS INTRO ═══════════ */
    if (state === "bossIntro") {
      if (bgImageRef.current && bgImageRef.current.complete) {
        ctx.drawImage(bgImageRef.current, 0, 0, W, H);
      }
      
      // Dark tint
      ctx.fillStyle = "rgba(40,0,20,0.6)";
      ctx.fillRect(0, 0, W, H);

      bossIntroTimerRef.current++;
      
      // Flash effect
      if (bossIntroTimerRef.current < 20) {
        ctx.fillStyle = `rgba(255,0,0,${0.3 - bossIntroTimerRef.current * 0.015})`;
        ctx.fillRect(0, 0, W, H);
      }

      // Boss appears
      if (bossRef.current) {
        const introProgress = Math.min(bossIntroTimerRef.current / 60, 1);
        bossRef.current.x = W + 100 - introProgress * (W * 0.3 + 100);
        bossRef.current.floatOffset += 0.03;
        drawBoss(ctx, bossRef.current, t);
      }

      // Text
      const textAlpha = Math.min(bossIntroTimerRef.current / 30, 1);
      ctx.globalAlpha = textAlpha;
      ctx.fillStyle = "#FF0000";
      ctx.font = "bold 48px Georgia";
      ctx.textAlign = "center";
      ctx.shadowColor = "#FF0000";
      ctx.shadowBlur = 20;
      ctx.fillText("THE DARK LORD APPEARS!", W / 2, H / 2);
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;

      if (bossIntroTimerRef.current > 120) {
        gameStateRef.current = "playing";
        setUiState("playing");
      }

      if (screenShakeRef.current > 0) ctx.restore();
      animFrameRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    /* ═══════════ TRANSITION ═══════════ */
    if (state === "transition") {
      if (startBgImageRef.current && startBgImageRef.current.complete) {
        ctx.drawImage(startBgImageRef.current, 0, 0, W, H);
      }
      transitionAlphaRef.current += 0.02;
      ctx.fillStyle = `rgba(0,0,0,${Math.min(transitionAlphaRef.current, 1)})`;
      ctx.fillRect(0, 0, W, H);
      if (transitionAlphaRef.current >= 1.2) {
        gameStateRef.current = "playing";
        setUiState("playing");
        resetGame();
      }
      if (screenShakeRef.current > 0) ctx.restore();
      animFrameRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    /* ═══════════ GAME OVER ═══════════ */
    if (state === "gameover") {
      if (bgImageRef.current && bgImageRef.current.complete) {
        ctx.drawImage(bgImageRef.current, 0, 0, W, H);
      } else {
        const skyGrad = ctx.createLinearGradient(0, 0, 0, H);
        skyGrad.addColorStop(0, "#0a0a2e");
        skyGrad.addColorStop(1, "#1a1a4e");
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, W, H);
      }

      gameOverFadeRef.current = Math.min(gameOverFadeRef.current + 0.02, 0.85);
      ctx.fillStyle = `rgba(0,0,0,${gameOverFadeRef.current})`;
      ctx.fillRect(0, 0, W, H);

      for (let i = 0; i < 20; i++) {
        const px = (Math.sin(t * 0.5 + i * 2) * 0.5 + 0.5) * W;
        const py = (Math.cos(t * 0.3 + i * 1.5) * 0.5 + 0.5) * H;
        ctx.fillStyle = `rgba(255,215,0,${0.15 + Math.sin(t + i) * 0.1})`;
        ctx.beginPath();
        ctx.arc(px, py, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      if (screenShakeRef.current > 0) ctx.restore();
      animFrameRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    /* ═══════════ VICTORY ═══════════ */
    if (state === "victory") {
      if (bgImageRef.current && bgImageRef.current.complete) {
        ctx.drawImage(bgImageRef.current, 0, 0, W, H);
      }

      // Golden victory overlay
      ctx.fillStyle = `rgba(255,215,0,${0.1 + Math.sin(t * 2) * 0.05})`;
      ctx.fillRect(0, 0, W, H);

      // Victory particles
      for (let i = 0; i < 50; i++) {
        const px = (Math.sin(t * 0.8 + i * 1.3) * 0.5 + 0.5) * W;
        const py = (Math.cos(t * 0.5 + i * 0.9) * 0.5 + 0.5) * H;
        ctx.fillStyle = `rgba(255,215,0,${0.3 + Math.sin(t * 2 + i) * 0.2})`;
        ctx.beginPath();
        ctx.arc(px, py, 2 + Math.sin(t + i) * 1, 0, Math.PI * 2);
        ctx.fill();
      }

      if (screenShakeRef.current > 0) ctx.restore();
      animFrameRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    /* ═══════════ PLAYING ═══════════ */

    // Background
    if (bgImageRef.current && bgImageRef.current.complete) {
      ctx.drawImage(bgImageRef.current, 0, 0, W, H);
    } else {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, H);
      skyGrad.addColorStop(0, "#050520");
      skyGrad.addColorStop(0.5, "#0a0a3e");
      skyGrad.addColorStop(1, "#15154e");
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, W, H);
    }

    // Level-based tint
    const currentLevelData = LEVELS[levelRef.current] || LEVELS[LEVELS.length - 1];
    ctx.fillStyle = currentLevelData.bgTint;
    ctx.fillRect(0, 0, W, H);

    // Dark overlay for depth
    ctx.fillStyle = "rgba(5,5,20,0.3)";
    ctx.fillRect(0, 0, W, H);

    // LUMOS BRIGHTNESS PULSE EFFECT
    if (activeSpellRef.current === "Lumos") {
      lumosPulseRef.current += 0.15;
      const brightness = 0.1 + Math.sin(lumosPulseRef.current) * 0.08;
      ctx.fillStyle = `rgba(255,220,100,${brightness})`;
      ctx.fillRect(0, 0, W, H);
    }

    // PATRONUS WAVE EFFECT
    if (activeSpellRef.current === "Expecto Patronum") {
      patronusWaveRef.current += 3;
      const waveRadius = patronusWaveRef.current % 400;
      const waveAlpha = Math.max(0, 0.3 - waveRadius / 400);
      const p = playerRef.current;
      ctx.strokeStyle = `rgba(100,200,255,${waveAlpha})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(p.x, p.y, waveRadius, 0, Math.PI * 2);
      ctx.stroke();
      const waveRadius2 = (patronusWaveRef.current + 200) % 400;
      const waveAlpha2 = Math.max(0, 0.3 - waveRadius2 / 400);
      ctx.strokeStyle = `rgba(100,200,255,${waveAlpha2})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, waveRadius2, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Stars
    starsRef.current.forEach((star) => {
      star.twinkle += star.speed;
      const alpha = 0.3 + Math.sin(star.twinkle) * 0.4;
      ctx.fillStyle = `rgba(255,255,240,${Math.max(0, alpha)})`;
      ctx.beginPath();
      ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
      ctx.fill();
    });

    // Clouds (parallax)
    cloudsRef.current.forEach((cloud) => {
      cloud.x -= cloud.speed;
      if (cloud.x + cloud.width < 0) {
        cloud.x = W + cloud.width;
        cloud.y = rand(0, H * 0.5);
      }
      ctx.globalAlpha = cloud.opacity;
      const cloudGrad = ctx.createRadialGradient(
        cloud.x + cloud.width / 2,
        cloud.y + cloud.height / 2,
        10,
        cloud.x + cloud.width / 2,
        cloud.y + cloud.height / 2,
        cloud.width / 2
      );
      cloudGrad.addColorStop(0, "rgba(100,110,140,0.3)");
      cloudGrad.addColorStop(1, "rgba(100,110,140,0)");
      ctx.fillStyle = cloudGrad;
      ctx.beginPath();
      ctx.ellipse(
        cloud.x + cloud.width / 2,
        cloud.y + cloud.height / 2,
        cloud.width / 2,
        cloud.height / 2,
        0, 0, Math.PI * 2
      );
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Ambient particles
    for (let i = 0; i < 15; i++) {
      const px = (Math.sin(t * 0.4 + i * 3.7) * 0.5 + 0.5) * W;
      const py = (Math.cos(t * 0.3 + i * 2.3) * 0.5 + 0.5) * H;
      const alpha = 0.1 + Math.sin(t * 1.5 + i) * 0.08;
      ctx.fillStyle = `rgba(180,200,255,${alpha})`;
      ctx.beginPath();
      ctx.arc(px, py, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // CHECK LEVEL PROGRESSION
    const prevLevel = levelRef.current;
    for (let i = LEVELS.length - 1; i >= 0; i--) {
      if (scoreRef.current >= LEVELS[i].scoreThreshold) {
        levelRef.current = i;
        break;
      }
    }
    
    if (levelRef.current > prevLevel && levelRef.current < LEVELS.length) {
      levelPopupRef.current = { text: `LEVEL ${levelRef.current + 1}: ${LEVELS[levelRef.current].name}`, timer: 120 };
      setCurrentLevel(levelRef.current);
      spawnParticles(W / 2, H / 2, 50, "#FFD700", 10);
      
      // Start boss fight at level 5
      if (levelRef.current === 4 && !bossRef.current) {
        bossRef.current = {
          x: W + 100,
          y: H / 2,
          health: 5,
          maxHealth: 5,
          phase: 0,
          attackTimer: 0,
          floatOffset: 0,
          shieldActive: false,
          spells: [],
        };
        bossIntroTimerRef.current = 0;
        gameStateRef.current = "bossIntro";
        setUiState("bossIntro");
        screenShakeRef.current = 30;
        dementorsRef.current = [];
      }
    }

    // UPDATE DIFFICULTY based on level
    const levelData = LEVELS[levelRef.current] || LEVELS[0];
    difficultyRef.current = levelData.speedMult;

    // SPAWN ENTITIES (only if not in boss fight)
    const inBossFight = levelRef.current === 4 && bossRef.current;
    
    if (!inBossFight) {
      spawnTimerRef.current.snitch++;
      spawnTimerRef.current.spell++;
      spawnTimerRef.current.dementor++;

      if (spawnTimerRef.current.snitch > 90 / levelData.spawnMult) {
        spawnTimerRef.current.snitch = 0;
        if (snitchesRef.current.length < 4) {
          snitchesRef.current.push({
            x: W + 30,
            y: rand(60, H - 60),
            wingAngle: 0,
            sparkles: [],
            bobOffset: rand(0, Math.PI * 2),
            speed: rand(1.5, 3) * difficultyRef.current,
          });
        }
      }

      if (spawnTimerRef.current.spell > 300 / levelData.spawnMult) {
        spawnTimerRef.current.spell = 0;
        if (spellOrbsRef.current.length < 2) {
          const spell = SPELLS[Math.floor(Math.random() * SPELLS.length)];
          spellOrbsRef.current.push({
            x: W + 30,
            y: rand(80, H - 80),
            spell: spell.name,
            color: spell.color,
            glowColor: spell.glowColor,
            pulseOffset: rand(0, Math.PI * 2),
            speed: rand(1, 2),
          });
        }
      }

      if (spawnTimerRef.current.dementor > Math.max(40, 120 / levelData.spawnMult)) {
        spawnTimerRef.current.dementor = 0;
        const maxDementors = 3 + levelRef.current;
        if (dementorsRef.current.length < maxDementors) {
          dementorsRef.current.push({
            x: W + 40,
            y: rand(60, H - 60),
            speed: rand(1.2, 2.5) * difficultyRef.current,
            floatOffset: rand(0, Math.PI * 2),
            smokeParticles: [],
            eyeGlow: rand(0, Math.PI * 2),
          });
        }
      }
    } else {
      // Boss fight - spawn snitches and spells less frequently
      spawnTimerRef.current.snitch++;
      spawnTimerRef.current.spell++;
      
      if (spawnTimerRef.current.snitch > 150) {
        spawnTimerRef.current.snitch = 0;
        if (snitchesRef.current.length < 2) {
          snitchesRef.current.push({
            x: W + 30,
            y: rand(60, H - 60),
            wingAngle: 0,
            sparkles: [],
            bobOffset: rand(0, Math.PI * 2),
            speed: rand(1.5, 2.5),
          });
        }
      }
      
      if (spawnTimerRef.current.spell > 200) {
        spawnTimerRef.current.spell = 0;
        if (spellOrbsRef.current.length < 1) {
          const spell = SPELLS[Math.floor(Math.random() * SPELLS.length)];
          spellOrbsRef.current.push({
            x: W + 30,
            y: rand(80, H - 80),
            spell: spell.name,
            color: spell.color,
            glowColor: spell.glowColor,
            pulseOffset: rand(0, Math.PI * 2),
            speed: rand(1, 2),
          });
        }
      }
    }

    // PLAYER UPDATE
    const p = playerRef.current;
    const accel = 0.5;
    const friction = 0.92;
    const maxSpeed = 7 * getSpeedMultiplier();
    const tc = touchControlsRef.current;

    if (keysRef.current["ArrowUp"] || keysRef.current["w"] || keysRef.current["W"] || tc.up) p.vy -= accel;
    if (keysRef.current["ArrowDown"] || keysRef.current["s"] || keysRef.current["S"] || tc.down) p.vy += accel;
    if (keysRef.current["ArrowLeft"] || keysRef.current["a"] || keysRef.current["A"] || tc.left) p.vx -= accel;
    if (keysRef.current["ArrowRight"] || keysRef.current["d"] || keysRef.current["D"] || tc.right) p.vx += accel;

    p.vx *= friction;
    p.vy *= friction;
    p.vx = Math.max(-maxSpeed, Math.min(maxSpeed, p.vx));
    p.vy = Math.max(-maxSpeed, Math.min(maxSpeed, p.vy));
    p.x += p.vx;
    p.y += p.vy;
    p.x = Math.max(30, Math.min(W - 30, p.x));
    p.y = Math.max(30, Math.min(H - 30, p.y));
    p.cloakWave += 0.08;
    p.auraPhase += 0.05;
    p.bobOffset += 0.04;

    // UPDATE SNITCHES
    snitchesRef.current.forEach((s) => {
      s.x -= s.speed;
      s.wingAngle += 0.3;
      if (frameCountRef.current % 3 === 0) {
        s.sparkles.push({
          x: s.x + rand(-5, 5),
          y: s.y + rand(-5, 5),
          alpha: 1,
          size: rand(1, 3),
        });
      }
      s.sparkles.forEach((sp) => (sp.alpha -= 0.03));
      s.sparkles = s.sparkles.filter((sp) => sp.alpha > 0);
    });
    snitchesRef.current = snitchesRef.current.filter((s) => s.x > -40);

    // UPDATE SPELL ORBS
    spellOrbsRef.current.forEach((orb) => {
      orb.x -= orb.speed;
    });
    spellOrbsRef.current = spellOrbsRef.current.filter((o) => o.x > -40);

    // UPDATE DEMENTORS
    const isSlowed = activeSpellRef.current === "Lumos";
    const isFrozen = activeSpellRef.current === "Stupefy";
    const isPatronus = activeSpellRef.current === "Expecto Patronum";

    dementorsRef.current.forEach((d) => {
      // Check if poisoned by snake
      const isPoisoned = poisonedEnemiesRef.current.has(d);
      
      if (!isFrozen) {
        let speedMult = isSlowed ? 0.3 : 1;
        // Snake poison slows enemies by 50%
        if (isPoisoned) speedMult *= 0.5;
        d.x -= d.speed * speedMult;
        const dy = p.y - d.y;
        d.y += Math.sign(dy) * 0.3 * speedMult;
      }
      d.floatOffset += 0.02;
      d.eyeGlow += 0.05;

      if (frameCountRef.current % 4 === 0) {
        d.smokeParticles.push({
          x: rand(-10, 10),
          y: rand(15, 30),
          alpha: 0.6,
          size: rand(3, 8),
        });
      }
      d.smokeParticles.forEach((sp) => {
        sp.y += 0.5;
        sp.alpha -= 0.015;
        sp.size += 0.1;
      });
      d.smokeParticles = d.smokeParticles.filter((sp) => sp.alpha > 0);
    });
    dementorsRef.current = dementorsRef.current.filter((d) => d.x > -60);

    // UPDATE BOSS
    if (bossRef.current) {
      const boss = bossRef.current;
      boss.floatOffset += 0.03;
      boss.attackTimer++;

      // Boss attacks
      if (boss.attackTimer > 90) {
        boss.attackTimer = 0;
        // Shoot spells at player
        const angle = Math.atan2(p.y - boss.y, p.x - boss.x);
        const spellSpeed = 5;
        boss.spells.push({
          x: boss.x - 40,
          y: boss.y,
          vx: Math.cos(angle) * spellSpeed,
          vy: Math.sin(angle) * spellSpeed,
          color: "#00FF00",
        });
        screenShakeRef.current = 5;
      }

      // Update boss spells
      boss.spells.forEach((spell) => {
        spell.x += spell.vx;
        spell.y += spell.vy;
      });
      boss.spells = boss.spells.filter((spell) => 
        spell.x > -20 && spell.x < W + 20 && spell.y > -20 && spell.y < H + 20
      );

      // Player collision with boss spells
      if (invincibleRef.current <= 0) {
        boss.spells = boss.spells.filter((spell) => {
          if (distance(p.x, p.y, spell.x, spell.y) < 25) {
            livesRef.current--;
            invincibleRef.current = 90;
            spawnParticles(p.x, p.y, 30, "#00FF00", 5);
            screenShakeRef.current = 15;
            if (livesRef.current <= 0) {
              gameStateRef.current = "gameover";
              setFinalScore(scoreRef.current);
              setFinalName(wizardNameRef.current);
              setUiState("gameover");
              gameOverFadeRef.current = 0;
            }
            return false;
          }
          return true;
        });
      }

      // Check if player spell hits boss
      if (activeSpellRef.current === "Expelliarmus" || activeSpellRef.current === "Stupefy") {
        if (distance(p.x, p.y, boss.x, boss.y) < 150 && spellTimerRef.current > 250) {
          boss.health--;
          spawnParticles(boss.x, boss.y, 40, "#FF0000", 8);
          screenShakeRef.current = 20;
          spellTimerRef.current = 200; // Prevent instant repeat hits
          
          if (boss.health <= 0) {
            // Victory!
            gameStateRef.current = "victory";
            setFinalScore(scoreRef.current + 100); // Bonus for beating boss
            setFinalName(wizardNameRef.current);
            setUiState("victory");
            bossRef.current = null;
            
            // Victory particles
            for (let i = 0; i < 100; i++) {
              spawnParticles(rand(0, W), rand(0, H), 3, "#FFD700", 5);
            }
          }
        }
      }
    }

    // SPELL TIMER
    const spellDuration = 300 * getSpellDurationMultiplier();
    if (spellTimerRef.current > 0) {
      spellTimerRef.current--;
      if (spellTimerRef.current <= 0) {
        activeSpellRef.current = "";
        lumosPulseRef.current = 0;
        patronusWaveRef.current = 0;
      }
    }

    // UPDATE COMPANION
    if (companionRef.current) {
      const companion = companionRef.current;
      const house = selectedHouseRef.current;
      const config = house ? COMPANION_CONFIGS[house.name] : null;
      
      // Smooth follow player (offset to the left and above)
      companion.targetX = p.x - 40;
      companion.targetY = p.y - 35;
      companion.x += (companion.targetX - companion.x) * 0.08;
      companion.y += (companion.targetY - companion.y) * 0.08;
      
      // Animation updates
      companion.floatOffset += 0.06;
      companion.glowPhase += 0.08;
      
      // Ability timer
      companion.abilityTimer++;
      
      // Shield timer (Hufflepuff)
      if (companion.shieldActive) {
        companion.shieldTimer--;
        if (companion.shieldTimer <= 0) {
          companion.shieldActive = false;
        }
      }
      
      // Update projectiles
      companion.projectiles.forEach((proj) => {
        proj.x += proj.vx;
        proj.y += proj.vy;
        proj.life--;
      });
      companion.projectiles = companion.projectiles.filter((proj) => proj.life > 0 && proj.x < W + 50);
      
      // Companion ability activations
      if (config && companion.abilityTimer >= config.abilityCooldown) {
        companion.abilityTimer = 0;
        
        if (companion.type === "phoenix" && dementorsRef.current.length > 0) {
          // Fire Phoenix: Shoot fire at nearest enemy
          let nearestDementor: Dementor | null = null;
          let nearestDist = Infinity;
          dementorsRef.current.forEach((d) => {
            const dist = distance(companion.x, companion.y, d.x, d.y);
            if (dist < nearestDist && dist < 400) {
              nearestDist = dist;
              nearestDementor = d;
            }
          });
          
          if (nearestDementor) {
            const angle = Math.atan2(nearestDementor.y - companion.y, nearestDementor.x - companion.x);
            companion.projectiles.push({
              x: companion.x + 15,
              y: companion.y,
              vx: Math.cos(angle) * 8,
              vy: Math.sin(angle) * 8,
              life: 60,
              color: "#FF6600",
            });
            spawnParticles(companion.x + 15, companion.y, 8, "#FF4400", 2);
          }
        } else if (companion.type === "snake" && dementorsRef.current.length > 0) {
          // Shadow Snake: Poison all nearby enemies (slow them)
          let poisonedAny = false;
          dementorsRef.current.forEach((d) => {
            const dist = distance(companion.x, companion.y, d.x, d.y);
            if (dist < 250 && !poisonedEnemiesRef.current.has(d)) {
              poisonedEnemiesRef.current.add(d);
              spawnParticles(d.x, d.y, 10, "#00FF66", 3);
              poisonedAny = true;
            }
          });
          if (poisonedAny) {
            companionPopupRef.current = { text: "Enemies Poisoned!", timer: 60 };
            spawnParticles(companion.x, companion.y, 15, "#00FF66", 4);
          }
        } else if (companion.type === "owl") {
          // Mystic Owl: Reveal power-ups (highlight spell orbs)
          if (spellOrbsRef.current.length > 0) {
            spellOrbsRef.current.forEach((orb) => {
              spawnParticles(orb.x, orb.y, 12, "#6699FF", 4);
            });
            companionPopupRef.current = { text: "Power-ups Revealed!", timer: 60 };
          }
          spawnParticles(companion.x, companion.y, 10, "#6699FF", 3);
        } else if (companion.type === "badger" && !companion.shieldActive) {
          // Guardian Badger: Generate protective shield
          companion.shieldActive = true;
          companion.shieldTimer = 300; // 5 seconds
          companionPopupRef.current = { text: "Shield Active!", timer: 60 };
          spawnParticles(p.x, p.y, 20, "#FFCC00", 5);
        }
      }
      
      // Check phoenix projectile hits
      if (companion.type === "phoenix") {
        companion.projectiles = companion.projectiles.filter((proj) => {
          let hit = false;
          dementorsRef.current = dementorsRef.current.filter((d) => {
            if (distance(proj.x, proj.y, d.x, d.y) < 35) {
              spawnParticles(d.x, d.y, 20, "#FF4400", 6);
              hit = true;
              return false; // Remove dementor
            }
            return true;
          });
          return !hit;
        });
      }
      
      // Badger shield blocks dementor damage
      if (companion.type === "badger" && companion.shieldActive && invincibleRef.current <= 0) {
        dementorsRef.current.forEach((d) => {
          if (distance(p.x, p.y, d.x, d.y) < 50) {
            // Push dementor away instead of taking damage
            const dx = d.x - p.x;
            const dy = d.y - p.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            d.x += (dx / dist) * 80;
            d.y += (dy / dist) * 30;
            spawnParticles(d.x, d.y, 10, "#FFCC00", 4);
          }
        });
      }
    }
    
    // Companion popup timer
    if (companionPopupRef.current) {
      companionPopupRef.current.timer--;
      if (companionPopupRef.current.timer <= 0) {
        companionPopupRef.current = null;
      }
    }

    // Spell popup timer
    if (spellPopupRef.current) {
      spellPopupRef.current.timer--;
      if (spellPopupRef.current.timer <= 0) {
        spellPopupRef.current = null;
      }
    }

    // Level popup timer
    if (levelPopupRef.current) {
      levelPopupRef.current.timer--;
      if (levelPopupRef.current.timer <= 0) {
        levelPopupRef.current = null;
      }
    }

    // COLLISIONS
    // Snitch collection
    snitchesRef.current = snitchesRef.current.filter((s) => {
      if (distance(p.x, p.y, s.x, s.y) < 30) {
        scoreRef.current += getSnitchBonus();
        spawnParticles(s.x, s.y, 20, "#FFD700", 4);
        return false;
      }
      return true;
    });

    // Spell orb collection
    spellOrbsRef.current = spellOrbsRef.current.filter((orb) => {
      if (distance(p.x, p.y, orb.x, orb.y) < 30) {
        activeSpellRef.current = orb.spell;
        spellTimerRef.current = spellDuration;
        spellPopupRef.current = { text: orb.spell, timer: 90 };
        spawnParticles(orb.x, orb.y, 25, orb.color, 5);
        scoreRef.current += 5;
        lumosPulseRef.current = 0;
        patronusWaveRef.current = 0;

        // Apply spell effects
        if (orb.spell === "Expecto Patronum") {
          dementorsRef.current.forEach((d) => {
            spawnParticles(d.x, d.y, 20, "#00BFFF", 8);
          });
          dementorsRef.current = [];
          for (let i = 0; i < 40; i++) {
            const angle = (i / 40) * Math.PI * 2;
            particlesRef.current.push({
              x: p.x, y: p.y,
              vx: Math.cos(angle) * 8,
              vy: Math.sin(angle) * 8,
              life: 60,
              maxLife: 60,
              size: rand(2, 5),
              color: "#00BFFF",
              alpha: 1,
            });
          }
        } else if (orb.spell === "Expelliarmus") {
          dementorsRef.current.forEach((d) => {
            const dx = d.x - p.x;
            const dy = d.y - p.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            d.x += (dx / dist) * 300;
            d.y += (dy / dist) * 100;
            spawnParticles(d.x, d.y, 15, "#FF4500", 6);
          });
          for (let i = 0; i < 30; i++) {
            const angle = (i / 30) * Math.PI * 2;
            particlesRef.current.push({
              x: p.x, y: p.y,
              vx: Math.cos(angle) * 10,
              vy: Math.sin(angle) * 10,
              life: 40,
              maxLife: 40,
              size: rand(3, 6),
              color: "#FF4500",
              alpha: 1,
            });
          }
          screenShakeRef.current = 10;
        } else if (orb.spell === "Stupefy") {
          dementorsRef.current.forEach((d) => {
            spawnParticles(d.x, d.y, 15, "#FF00FF", 4);
          });
        } else if (orb.spell === "Lumos") {
          spawnParticles(p.x, p.y, 30, "#FFD700", 6);
        }
        return false;
      }
      return true;
    });

    // Dementor collision with player (Patronus makes player invincible to dementors)
    if (invincibleRef.current > 0) {
      invincibleRef.current--;
    } else if (!isPatronus) {
      dementorsRef.current = dementorsRef.current.filter((d) => {
        if (distance(p.x, p.y, d.x, d.y) < 35) {
          livesRef.current--;
          invincibleRef.current = 90;
          spawnParticles(p.x, p.y, 30, "#FF0000", 5);
          screenShakeRef.current = 10;
          if (livesRef.current <= 0) {
            gameStateRef.current = "gameover";
            setFinalScore(scoreRef.current);
            setFinalName(wizardNameRef.current);
            setUiState("gameover");
            gameOverFadeRef.current = 0;
          }
          return false;
        }
        return true;
      });
    }

    // UPDATE PARTICLES
    particlesRef.current.forEach((part) => {
      part.x += part.vx;
      part.y += part.vy;
      part.life--;
      part.alpha = Math.max(0, part.life / part.maxLife);
      part.vx *= 0.98;
      part.vy *= 0.98;
    });
    particlesRef.current = particlesRef.current.filter((p) => p.life > 0);

    // DRAW ENTITIES

    // Snitches
    snitchesRef.current.forEach((s) => drawSnitch(ctx, s, t));

    // Spell orbs
    spellOrbsRef.current.forEach((orb) => drawSpellOrb(ctx, orb, t));

    // Dementors (with frozen effect or patronus ghost effect)
    dementorsRef.current.forEach((d) => {
      if (isFrozen) {
        ctx.globalAlpha = 0.5;
        ctx.save();
      } else if (isPatronus) {
        ctx.globalAlpha = 0.4;
      }
      drawDementor(ctx, d, t);
      ctx.globalAlpha = 1;
      if (isFrozen) {
        ctx.restore();
      }
    });

    // Boss and boss spells
    if (bossRef.current) {
      drawBoss(ctx, bossRef.current, t);
      
      // Draw boss spells
      bossRef.current.spells.forEach((spell) => {
        ctx.shadowColor = spell.color;
        ctx.shadowBlur = 15;
        ctx.fillStyle = spell.color;
        ctx.beginPath();
        ctx.arc(spell.x, spell.y, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });
    }

    // Player (with invincibility flash)
    if (invincibleRef.current > 0 && Math.floor(invincibleRef.current / 5) % 2 === 0) {
      ctx.globalAlpha = 0.5;
    }
    drawWizard(ctx, p, t);
    ctx.globalAlpha = 1;

    // DRAW PARTICLES
    particlesRef.current.forEach((part) => {
      ctx.globalAlpha = part.alpha;
      ctx.shadowColor = part.color;
      ctx.shadowBlur = 8;
      ctx.fillStyle = part.color;
      ctx.beginPath();
      ctx.arc(part.x, part.y, part.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;

    // ACTIVE SPELL VISUAL EFFECT
    if (activeSpellRef.current) {
      let spellColor = "#00BFFF";
      if (activeSpellRef.current === "Lumos") spellColor = "#FFD700";
      else if (activeSpellRef.current === "Expelliarmus") spellColor = "#FF4500";
      else if (activeSpellRef.current === "Stupefy") spellColor = "#FF00FF";

      const edgeGrad = ctx.createLinearGradient(0, 0, 50, 0);
      edgeGrad.addColorStop(0, spellColor + "33");
      edgeGrad.addColorStop(1, spellColor + "00");
      ctx.fillStyle = edgeGrad;
      ctx.fillRect(0, 0, 50, H);

      const edgeGrad2 = ctx.createLinearGradient(W, 0, W - 50, 0);
      edgeGrad2.addColorStop(0, spellColor + "33");
      edgeGrad2.addColorStop(1, spellColor + "00");
      ctx.fillStyle = edgeGrad2;
      ctx.fillRect(W - 50, 0, 50, H);

      const edgeGrad3 = ctx.createLinearGradient(0, 0, 0, 50);
      edgeGrad3.addColorStop(0, spellColor + "33");
      edgeGrad3.addColorStop(1, spellColor + "00");
      ctx.fillStyle = edgeGrad3;
      ctx.fillRect(0, 0, W, 50);

      const edgeGrad4 = ctx.createLinearGradient(0, H, 0, H - 50);
      edgeGrad4.addColorStop(0, spellColor + "33");
      edgeGrad4.addColorStop(1, spellColor + "00");
      ctx.fillStyle = edgeGrad4;
      ctx.fillRect(0, H - 50, W, 50);
    }

    // DRAW UI ON CANVAS

    // Top left: Name, Score, Lives, Level
    ctx.shadowColor = "rgba(0,0,0,0.8)";
    ctx.shadowBlur = 4;
    ctx.fillStyle = selectedHouseRef.current?.colors.glow || "#FFD700";
    ctx.font = "bold 18px 'Georgia', serif";
    ctx.textAlign = "left";
    ctx.fillText(wizardNameRef.current, 20, 35);

    ctx.fillStyle = "#FFFFFF";
    ctx.font = "16px 'Georgia', serif";
    ctx.fillText(`Score: ${scoreRef.current}`, 20, 60);
    
    // Level indicator
    ctx.fillStyle = "#87CEEB";
    ctx.font = "14px 'Georgia', serif";
    ctx.fillText(`Level ${levelRef.current + 1}: ${LEVELS[levelRef.current]?.name || "Unknown"}`, 20, 82);

    // Lives as hearts
    for (let i = 0; i < livesRef.current; i++) {
      const hx = 22 + i * 28;
      const hy = 98;
      ctx.fillStyle = "#FF2255";
      ctx.shadowColor = "#FF2255";
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.moveTo(hx, hy + 4);
      ctx.bezierCurveTo(hx, hy, hx - 8, hy, hx - 8, hy + 4);
      ctx.bezierCurveTo(hx - 8, hy + 10, hx, hy + 14, hx, hy + 16);
      ctx.bezierCurveTo(hx, hy + 14, hx + 8, hy + 10, hx + 8, hy + 4);
      ctx.bezierCurveTo(hx + 8, hy, hx, hy, hx, hy + 4);
      ctx.fill();
    }
    ctx.shadowBlur = 0;

    // Top right: Active spell
    if (activeSpellRef.current) {
      ctx.textAlign = "right";
      ctx.shadowColor = "rgba(0,0,0,0.8)";
      ctx.shadowBlur = 4;
      ctx.fillStyle = "#FFD700";
      ctx.font = "bold 14px 'Georgia', serif";
      ctx.fillText("Active Spell:", W - 20, 35);

      let spellColor = "#00BFFF";
      if (activeSpellRef.current === "Lumos") spellColor = "#FFD700";
      else if (activeSpellRef.current === "Expelliarmus") spellColor = "#FF4500";
      else if (activeSpellRef.current === "Stupefy") spellColor = "#FF00FF";
      ctx.fillStyle = spellColor;
      ctx.font = "bold 18px 'Georgia', serif";
      ctx.fillText(activeSpellRef.current, W - 20, 58);

      const barWidth = 120;
      const barX = W - 20 - barWidth;
      const barY = 65;
      ctx.fillStyle = "rgba(255,255,255,0.15)";
      ctx.fillRect(barX, barY, barWidth, 6);
      ctx.fillStyle = spellColor;
      ctx.fillRect(barX, barY, barWidth * (spellTimerRef.current / spellDuration), 6);
      ctx.shadowBlur = 0;
    }

    // Center spell popup
    if (spellPopupRef.current) {
      const popup = spellPopupRef.current;
      const popAlpha = Math.min(1, popup.timer / 30);
      ctx.globalAlpha = popAlpha;
      ctx.textAlign = "center";

      ctx.shadowColor = "rgba(0,0,0,0.8)";
      ctx.shadowBlur = 8;
      ctx.fillStyle = "#FFD700";
      ctx.font = "bold 28px 'Georgia', serif";
      ctx.fillText(popup.text + "!", W / 2, H / 2 - 20 - (90 - popup.timer) * 0.3);

      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    }

    // Level up popup
    if (levelPopupRef.current) {
      const popup = levelPopupRef.current;
      const popAlpha = Math.min(1, popup.timer / 30);
      ctx.globalAlpha = popAlpha;
      ctx.textAlign = "center";

      ctx.shadowColor = "rgba(255,215,0,0.8)";
      ctx.shadowBlur = 15;
      ctx.fillStyle = "#FFD700";
      ctx.font = "bold 36px 'Georgia', serif";
      ctx.fillText(popup.text, W / 2, H / 2 + 40 - (120 - popup.timer) * 0.2);

      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    }

    // Controls hint (first few seconds)
    if (frameCountRef.current < 300) {
      const hintAlpha = Math.max(0, 1 - frameCountRef.current / 300);
      ctx.globalAlpha = hintAlpha;
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.font = "14px 'Georgia', serif";
      ctx.fillText(isMobile ? "Use touch controls to fly" : "Use Arrow Keys or WASD to fly", W / 2, H - 40);
      ctx.globalAlpha = 1;
    }

    if (screenShakeRef.current > 0) ctx.restore();
    animFrameRef.current = requestAnimationFrame(gameLoop);
  }, [resetGame, isMobile]);

  /* ───────────── SETUP ───────────── */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Check for mobile
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768 || 'ontouchstart' in window);
    };
    checkMobile();

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      checkMobile();
    };
    resize();
    window.addEventListener("resize", resize);

    // Load images
    const bgImg = new Image();
    bgImg.crossOrigin = "anonymous";
    bgImg.src = "/images/game-sky.jpg";
    bgImageRef.current = bgImg;

    const startImg = new Image();
    startImg.crossOrigin = "anonymous";
    startImg.src = "/images/hogwarts-bg.jpg";
    startBgImageRef.current = startImg;

    // Keyboard
    const onKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.key] = true;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) {
        e.preventDefault();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key] = false;
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    // Init clouds/stars for start screen
    initClouds(canvas.width, canvas.height);
    initStars(canvas.width, canvas.height);

    // Start loop
    animFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [gameLoop, initClouds, initStars]);

  /* ───────────── EVENT HANDLERS ───────────── */
  const handleSelectHouse = (house: House) => {
    setSelectedHouse(house);
    selectedHouseRef.current = house;
    gameStateRef.current = "characterSelect";
    setUiState("characterSelect");
  };

  const handleSelectCharacter = (character: string) => {
    setSelectedCharacter(character);
    wizardNameRef.current = character;
    gameStateRef.current = "start";
    setUiState("start");
  };

  const handleStartGame = () => {
    gameStateRef.current = "transition";
    transitionAlphaRef.current = 0;
    setUiState("transition");
  };

  const handleRestart = () => {
    resetGame();
    gameStateRef.current = "playing";
    setUiState("playing");
  };

  const handleBackToHouseSelect = () => {
    setSelectedHouse(null);
    selectedHouseRef.current = null;
    setSelectedCharacter("");
    gameStateRef.current = "houseSelect";
    setUiState("houseSelect");
  };

  /* Touch control handlers */
  const handleTouchStart = (direction: 'up' | 'down' | 'left' | 'right') => {
    touchControlsRef.current[direction] = true;
  };

  const handleTouchEnd = (direction: 'up' | 'down' | 'left' | 'right') => {
    touchControlsRef.current[direction] = false;
  };

  /* ───────────── RENDER ───────────── */
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050510]">
      {/* Canvas always renders */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* MOBILE TOUCH CONTROLS */}
      {isMobile && uiState === "playing" && (
        <div className="absolute bottom-4 left-4 right-4 z-20 flex justify-between items-end pointer-events-none">
          {/* Left side - directional controls */}
          <div className="relative w-36 h-36 pointer-events-auto">
            {/* Up */}
            <button
              onTouchStart={() => handleTouchStart('up')}
              onTouchEnd={() => handleTouchEnd('up')}
              onMouseDown={() => handleTouchStart('up')}
              onMouseUp={() => handleTouchEnd('up')}
              onMouseLeave={() => handleTouchEnd('up')}
              className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full flex items-center justify-center"
              style={{
                background: "rgba(255,215,0,0.3)",
                border: "2px solid rgba(255,215,0,0.5)",
                touchAction: "none",
              }}
            >
              <svg className="w-6 h-6 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4l-8 8h6v8h4v-8h6z" />
              </svg>
            </button>
            {/* Down */}
            <button
              onTouchStart={() => handleTouchStart('down')}
              onTouchEnd={() => handleTouchEnd('down')}
              onMouseDown={() => handleTouchStart('down')}
              onMouseUp={() => handleTouchEnd('down')}
              onMouseLeave={() => handleTouchEnd('down')}
              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full flex items-center justify-center"
              style={{
                background: "rgba(255,215,0,0.3)",
                border: "2px solid rgba(255,215,0,0.5)",
                touchAction: "none",
              }}
            >
              <svg className="w-6 h-6 text-yellow-400 rotate-180" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4l-8 8h6v8h4v-8h6z" />
              </svg>
            </button>
            {/* Left */}
            <button
              onTouchStart={() => handleTouchStart('left')}
              onTouchEnd={() => handleTouchEnd('left')}
              onMouseDown={() => handleTouchStart('left')}
              onMouseUp={() => handleTouchEnd('left')}
              onMouseLeave={() => handleTouchEnd('left')}
              className="absolute top-1/2 left-0 -translate-y-1/2 w-12 h-12 rounded-full flex items-center justify-center"
              style={{
                background: "rgba(255,215,0,0.3)",
                border: "2px solid rgba(255,215,0,0.5)",
                touchAction: "none",
              }}
            >
              <svg className="w-6 h-6 text-yellow-400 -rotate-90" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4l-8 8h6v8h4v-8h6z" />
              </svg>
            </button>
            {/* Right */}
            <button
              onTouchStart={() => handleTouchStart('right')}
              onTouchEnd={() => handleTouchEnd('right')}
              onMouseDown={() => handleTouchStart('right')}
              onMouseUp={() => handleTouchEnd('right')}
              onMouseLeave={() => handleTouchEnd('right')}
              className="absolute top-1/2 right-0 -translate-y-1/2 w-12 h-12 rounded-full flex items-center justify-center"
              style={{
                background: "rgba(255,215,0,0.3)",
                border: "2px solid rgba(255,215,0,0.5)",
                touchAction: "none",
              }}
            >
              <svg className="w-6 h-6 text-yellow-400 rotate-90" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4l-8 8h6v8h4v-8h6z" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* HOUSE SELECTION OVERLAY */}
      {uiState === "houseSelect" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 p-4">
          {/* Title */}
          <div className="flex flex-col items-center mb-8 animate-fadeIn">
            <div
              className="text-4xl md:text-6xl font-bold tracking-wider mb-2 text-transparent bg-clip-text"
              style={{
                backgroundImage: "linear-gradient(180deg, #FFD700 0%, #B8860B 100%)",
                fontFamily: "'Georgia', serif",
                filter: "drop-shadow(0 0 20px rgba(255,215,0,0.4))",
              }}
            >
              Choose Your House
            </div>
            <div className="flex items-center gap-3 mt-3">
              <div className="h-px w-16 md:w-24 bg-gradient-to-r from-transparent to-[#FFD70066]" />
              <div
                className="w-2 h-2 rotate-45"
                style={{
                  backgroundColor: "#FFD700",
                  boxShadow: "0 0 8px #FFD700",
                }}
              />
              <div className="h-px w-16 md:w-24 bg-gradient-to-l from-transparent to-[#FFD70066]" />
            </div>
          </div>

          {/* House Cards Grid */}
          <div className="grid grid-cols-2 gap-4 md:gap-6 max-w-2xl w-full animate-fadeInUp">
            {HOUSES.map((house) => (
              <button
                key={house.name}
                onClick={() => handleSelectHouse(house)}
                onMouseEnter={() => setHoveredHouse(house.name)}
                onMouseLeave={() => setHoveredHouse(null)}
                className="relative p-6 md:p-8 rounded-xl transition-all duration-300 cursor-pointer group"
                style={{
                  background: `linear-gradient(135deg, ${house.colors.primary}CC 0%, ${house.colors.primary}99 100%)`,
                  border: `2px solid ${hoveredHouse === house.name ? house.colors.glow : house.colors.secondary}`,
                  boxShadow: hoveredHouse === house.name
                    ? `0 0 40px ${house.colors.glow}66, 0 0 80px ${house.colors.glow}33, inset 0 0 30px ${house.colors.glow}22`
                    : `0 4px 20px rgba(0,0,0,0.5), inset 0 0 20px ${house.colors.primary}44`,
                  transform: hoveredHouse === house.name ? "scale(1.05)" : "scale(1)",
                }}
              >
                {/* Animated glow border */}
                <div
                  className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{
                    boxShadow: `inset 0 0 20px ${house.colors.glow}44`,
                  }}
                />

                {/* House emblem placeholder */}
                <div
                  className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-4 rounded-full flex items-center justify-center"
                  style={{
                    background: `radial-gradient(circle, ${house.colors.secondary} 0%, ${house.colors.primary} 100%)`,
                    border: `2px solid ${house.colors.glow}`,
                    boxShadow: `0 0 15px ${house.colors.glow}55`,
                  }}
                >
                  <span
                    className="text-3xl md:text-4xl font-bold"
                    style={{
                      color: house.colors.glow,
                      textShadow: `0 0 10px ${house.colors.glow}`,
                    }}
                  >
                    {house.name[0]}
                  </span>
                </div>

                {/* House name */}
                <div
                  className="text-xl md:text-2xl font-bold text-center"
                  style={{
                    color: house.colors.glow,
                    fontFamily: "'Georgia', serif",
                    textShadow: `0 0 15px ${house.colors.glow}88`,
                  }}
                >
                  {house.name}
                </div>

                {/* House ability */}
                <div
                  className="text-xs md:text-sm text-center mt-2 opacity-80"
                  style={{
                    color: house.colors.glow,
                    fontFamily: "'Georgia', serif",
                  }}
                >
                  {house.abilityDesc}
                </div>

                {/* Sparkle effects on hover */}
                {hoveredHouse === house.name && (
                  <>
                    <div
                      className="absolute top-2 right-2 w-1 h-1 rounded-full animate-ping"
                      style={{ backgroundColor: house.colors.glow }}
                    />
                    <div
                      className="absolute bottom-4 left-4 w-1.5 h-1.5 rounded-full animate-ping"
                      style={{ backgroundColor: house.colors.glow, animationDelay: "0.3s" }}
                    />
                    <div
                      className="absolute top-1/2 right-4 w-1 h-1 rounded-full animate-ping"
                      style={{ backgroundColor: house.colors.glow, animationDelay: "0.6s" }}
                    />
                  </>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* CHARACTER SELECTION OVERLAY */}
      {uiState === "characterSelect" && selectedHouse && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 p-4">
          {/* Back button */}
          <button
            onClick={handleBackToHouseSelect}
            className="absolute top-6 left-6 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 hover:scale-105 cursor-pointer"
            style={{
              backgroundColor: "rgba(20,15,40,0.8)",
              border: "1px solid rgba(255,215,0,0.3)",
              color: "#C0A060",
              fontFamily: "'Georgia', serif",
            }}
          >
            Back
          </button>

          {/* Title */}
          <div className="flex flex-col items-center mb-8 animate-fadeIn">
            <div
              className="text-xl md:text-2xl tracking-widest uppercase mb-2"
              style={{
                color: selectedHouse.colors.glow,
                fontFamily: "'Georgia', serif",
                textShadow: `0 0 15px ${selectedHouse.colors.glow}66`,
              }}
            >
              {selectedHouse.name}
            </div>
            <div
              className="text-3xl md:text-5xl font-bold tracking-wider text-transparent bg-clip-text"
              style={{
                backgroundImage: "linear-gradient(180deg, #FFD700 0%, #B8860B 100%)",
                fontFamily: "'Georgia', serif",
                filter: "drop-shadow(0 0 20px rgba(255,215,0,0.4))",
              }}
            >
              Choose Your Character
            </div>
            <div className="flex items-center gap-3 mt-4">
              <div className="h-px w-16 md:w-24 bg-gradient-to-r from-transparent to-[#FFD70066]" />
              <div
                className="w-2 h-2 rotate-45"
                style={{
                  backgroundColor: selectedHouse.colors.glow,
                  boxShadow: `0 0 8px ${selectedHouse.colors.glow}`,
                }}
              />
              <div className="h-px w-16 md:w-24 bg-gradient-to-l from-transparent to-[#FFD70066]" />
            </div>
          </div>

          {/* Character Buttons */}
          <div className="flex flex-wrap justify-center gap-3 md:gap-4 max-w-xl animate-fadeInUp">
            {selectedHouse.characters.map((character, index) => (
              <button
                key={character}
                onClick={() => handleSelectCharacter(character)}
                className="px-6 py-3 md:px-8 md:py-4 rounded-xl font-bold text-lg transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
                style={{
                  background: `linear-gradient(135deg, ${selectedHouse.colors.primary}DD 0%, ${selectedHouse.colors.primary}AA 100%)`,
                  border: `1px solid ${selectedHouse.colors.secondary}`,
                  color: selectedHouse.colors.glow,
                  fontFamily: "'Georgia', serif",
                  boxShadow: `0 4px 15px rgba(0,0,0,0.4), inset 0 0 15px ${selectedHouse.colors.glow}11`,
                  animationDelay: `${index * 0.1}s`,
                }}
              >
                {character}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* START SCREEN OVERLAY (after character selection) */}
      {uiState === "start" && selectedHouse && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
          {/* Back button */}
          <button
            onClick={() => {
              gameStateRef.current = "characterSelect";
              setUiState("characterSelect");
            }}
            className="absolute top-6 left-6 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 hover:scale-105 cursor-pointer"
            style={{
              backgroundColor: "rgba(20,15,40,0.8)",
              border: "1px solid rgba(255,215,0,0.3)",
              color: "#C0A060",
              fontFamily: "'Georgia', serif",
            }}
          >
            Back
          </button>

          {/* Title area */}
          <div className="flex flex-col items-center mb-8 animate-fadeIn">
            <div
              className="text-5xl md:text-7xl font-bold tracking-wider mb-2 text-transparent bg-clip-text"
              style={{
                backgroundImage: "linear-gradient(180deg, #FFD700 0%, #B8860B 100%)",
                fontFamily: "'Georgia', serif",
                filter: "drop-shadow(0 0 20px rgba(255,215,0,0.4))",
              }}
            >
              Harry Potter
            </div>
            <div
              className="text-xl md:text-2xl tracking-[0.3em] uppercase mt-1"
              style={{
                color: "#C0A060",
                fontFamily: "'Georgia', serif",
                textShadow: "0 0 15px rgba(192,160,96,0.5)",
              }}
            >
              Wizard Flight
            </div>
            {/* Decorative line */}
            <div className="flex items-center gap-3 mt-4">
              <div className="h-px w-16 md:w-24 bg-gradient-to-r from-transparent to-[#FFD70066]" />
              <div
                className="w-2 h-2 rotate-45"
                style={{
                  backgroundColor: "#FFD700",
                  boxShadow: "0 0 8px #FFD700",
                }}
              />
              <div className="h-px w-16 md:w-24 bg-gradient-to-l from-transparent to-[#FFD70066]" />
            </div>
          </div>

          {/* Player Info */}
          <div className="flex flex-col items-center gap-4 mb-8 animate-fadeInUp">
            <div
              className="flex items-center gap-4 px-6 py-3 rounded-xl"
              style={{
                backgroundColor: "rgba(20,15,40,0.8)",
                border: `1px solid ${selectedHouse.colors.secondary}`,
                boxShadow: `0 0 20px ${selectedHouse.colors.glow}22`,
              }}
            >
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{
                  background: `linear-gradient(135deg, ${selectedHouse.colors.primary} 0%, ${selectedHouse.colors.secondary} 100%)`,
                  border: `2px solid ${selectedHouse.colors.glow}`,
                }}
              >
                <span
                  className="text-xl font-bold"
                  style={{ color: selectedHouse.colors.glow }}
                >
                  {selectedHouse.name[0]}
                </span>
              </div>
              <div className="flex flex-col">
                <span
                  className="text-xl font-bold"
                  style={{
                    color: selectedHouse.colors.glow,
                    fontFamily: "'Georgia', serif",
                  }}
                >
                  {selectedCharacter}
                </span>
                <span
                  className="text-sm"
                  style={{
                    color: selectedHouse.colors.secondary,
                    fontFamily: "'Georgia', serif",
                  }}
                >
                  {selectedHouse.name} - {selectedHouse.ability}
                </span>
              </div>
            </div>
          </div>

          {/* Start Button */}
          <div className="flex flex-col items-center gap-5 animate-fadeInUp">
            <button
              onClick={handleStartGame}
              className="relative px-12 py-4 rounded-lg text-xl font-bold tracking-wider uppercase transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${selectedHouse.colors.primary} 0%, ${selectedHouse.colors.secondary} 50%, ${selectedHouse.colors.primary} 100%)`,
                color: selectedHouse.colors.glow,
                fontFamily: "'Georgia', serif",
                boxShadow: `0 0 30px ${selectedHouse.colors.glow}44, 0 4px 15px rgba(0,0,0,0.5)`,
                border: `1px solid ${selectedHouse.colors.glow}66`,
              }}
            >
              Start Game
              <div
                className="absolute inset-0 rounded-lg animate-pulse pointer-events-none"
                style={{
                  boxShadow: `0 0 40px ${selectedHouse.colors.glow}33`,
                }}
              />
            </button>

            <p
              className="text-sm mt-2 opacity-60"
              style={{
                color: "#8090a0",
                fontFamily: "'Georgia', serif",
              }}
            >
              {isMobile ? "Use touch controls to fly" : "Use Arrow Keys or WASD to fly"}
            </p>
          </div>
        </div>
      )}

      {/* TRANSITION OVERLAY */}
      {uiState === "transition" && (
        <div className="absolute inset-0 z-20 pointer-events-none animate-fadeToBlack" />
      )}

      {/* BOSS INTRO OVERLAY */}
      {uiState === "bossIntro" && (
        <div className="absolute inset-0 z-15 pointer-events-none" />
      )}

      {/* PLAYING STATE - no overlay needed, just canvas */}
      {uiState === "playing" && null}

      {/* GAME OVER OVERLAY */}
      {uiState === "gameover" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 animate-fadeIn">
          <div className="flex flex-col items-center gap-6 p-10 rounded-2xl"
            style={{
              backgroundColor: "rgba(10,5,25,0.85)",
              border: `1px solid ${selectedHouse?.colors.glow || "#FFD700"}33`,
              boxShadow: `0 0 60px ${selectedHouse?.colors.glow || "#FFD700"}22, inset 0 0 40px ${selectedHouse?.colors.glow || "#FFD700"}08`,
            }}
          >
            <div
              className="text-3xl md:text-4xl font-bold"
              style={{
                color: "#FF4444",
                fontFamily: "'Georgia', serif",
                textShadow: "0 0 20px rgba(255,68,68,0.5)",
              }}
            >
              Game Over
            </div>

            <div className="flex flex-col items-center gap-2">
              <div
                className="text-lg"
                style={{
                  color: selectedHouse?.colors.glow || "#C0A060",
                  fontFamily: "'Georgia', serif",
                }}
              >
                {finalName}
              </div>
              <div
                className="text-5xl font-bold"
                style={{
                  color: "#FFD700",
                  fontFamily: "'Georgia', serif",
                  textShadow: "0 0 20px rgba(255,215,0,0.5)",
                }}
              >
                {finalScore}
              </div>
              <div
                className="text-sm uppercase tracking-widest"
                style={{
                  color: "#8090a0",
                  fontFamily: "'Georgia', serif",
                }}
              >
                Points
              </div>
              <div
                className="text-sm mt-2"
                style={{
                  color: "#87CEEB",
                  fontFamily: "'Georgia', serif",
                }}
              >
                Reached Level {currentLevel + 1}
              </div>
            </div>

            {/* Decorative line */}
            <div className="flex items-center gap-3">
              <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#FFD70044]" />
              <div
                className="w-2 h-2 rotate-45"
                style={{ backgroundColor: selectedHouse?.colors.glow || "#FFD700", boxShadow: `0 0 8px ${selectedHouse?.colors.glow || "#FFD700"}` }}
              />
              <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#FFD70044]" />
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleRestart}
                className="px-8 py-3 rounded-lg text-lg font-bold tracking-wider uppercase transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
                style={{
                  background: `linear-gradient(135deg, ${selectedHouse?.colors.primary || "#B8860B"} 0%, ${selectedHouse?.colors.secondary || "#FFD700"} 50%, ${selectedHouse?.colors.primary || "#B8860B"} 100%)`,
                  color: selectedHouse?.colors.glow || "#1a0a00",
                  fontFamily: "'Georgia', serif",
                  boxShadow: `0 0 30px ${selectedHouse?.colors.glow || "#FFD700"}44, 0 4px 15px rgba(0,0,0,0.5)`,
                  border: `1px solid ${selectedHouse?.colors.glow || "#FFD700"}66`,
                }}
              >
                Play Again
              </button>

              <button
                onClick={handleBackToHouseSelect}
                className="px-6 py-3 rounded-lg text-lg font-bold tracking-wider uppercase transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
                style={{
                  backgroundColor: "rgba(30,20,50,0.9)",
                  color: "#C0A060",
                  fontFamily: "'Georgia', serif",
                  boxShadow: "0 4px 15px rgba(0,0,0,0.5)",
                  border: "1px solid rgba(192,160,96,0.3)",
                }}
              >
                Change House
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VICTORY OVERLAY */}
      {uiState === "victory" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 animate-fadeIn">
          <div className="flex flex-col items-center gap-6 p-10 rounded-2xl"
            style={{
              backgroundColor: "rgba(10,5,25,0.85)",
              border: `1px solid #FFD70055`,
              boxShadow: `0 0 80px rgba(255,215,0,0.4), inset 0 0 40px rgba(255,215,0,0.1)`,
            }}
          >
            <div
              className="text-4xl md:text-5xl font-bold"
              style={{
                color: "#FFD700",
                fontFamily: "'Georgia', serif",
                textShadow: "0 0 30px rgba(255,215,0,0.8)",
              }}
            >
              VICTORY!
            </div>

            <div
              className="text-xl text-center"
              style={{
                color: "#87CEEB",
                fontFamily: "'Georgia', serif",
              }}
            >
              The Dark Lord has been defeated!
            </div>

            <div className="flex flex-col items-center gap-2">
              <div
                className="text-lg"
                style={{
                  color: selectedHouse?.colors.glow || "#C0A060",
                  fontFamily: "'Georgia', serif",
                }}
              >
                {finalName} of {selectedHouse?.name}
              </div>
              <div
                className="text-5xl font-bold"
                style={{
                  color: "#FFD700",
                  fontFamily: "'Georgia', serif",
                  textShadow: "0 0 20px rgba(255,215,0,0.5)",
                }}
              >
                {finalScore}
              </div>
              <div
                className="text-sm uppercase tracking-widest"
                style={{
                  color: "#8090a0",
                  fontFamily: "'Georgia', serif",
                }}
              >
                Final Score
              </div>
            </div>

            {/* Decorative line */}
            <div className="flex items-center gap-3">
              <div className="h-px w-24 bg-gradient-to-r from-transparent to-[#FFD70066]" />
              <div
                className="w-3 h-3 rotate-45"
                style={{ backgroundColor: "#FFD700", boxShadow: "0 0 12px #FFD700" }}
              />
              <div className="h-px w-24 bg-gradient-to-l from-transparent to-[#FFD70066]" />
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleRestart}
                className="px-8 py-3 rounded-lg text-lg font-bold tracking-wider uppercase transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
                style={{
                  background: `linear-gradient(135deg, #B8860B 0%, #FFD700 50%, #B8860B 100%)`,
                  color: "#1a0a00",
                  fontFamily: "'Georgia', serif",
                  boxShadow: `0 0 30px rgba(255,215,0,0.5), 0 4px 15px rgba(0,0,0,0.5)`,
                  border: `1px solid #FFD70088`,
                }}
              >
                Play Again
              </button>

              <button
                onClick={handleBackToHouseSelect}
                className="px-6 py-3 rounded-lg text-lg font-bold tracking-wider uppercase transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer"
                style={{
                  backgroundColor: "rgba(30,20,50,0.9)",
                  color: "#C0A060",
                  fontFamily: "'Georgia', serif",
                  boxShadow: "0 4px 15px rgba(0,0,0,0.5)",
                  border: "1px solid rgba(192,160,96,0.3)",
                }}
              >
                Change House
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom CSS animations */}
      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeToBlack {
          from { background: rgba(0,0,0,0); }
          to { background: rgba(0,0,0,1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.8s ease-out;
        }
        .animate-fadeInUp {
          animation: fadeInUp 1s ease-out 0.3s both;
        }
        .animate-fadeToBlack {
          animation: fadeToBlack 1.5s ease-in forwards;
        }
        input::placeholder {
          color: rgba(192,160,96,0.4);
        }
      `}</style>

      {/* FALLBACK LOADING UI - only shows if no other state matches */}
      {!["houseSelect", "characterSelect", "start", "playing", "gameover", "transition", "victory", "bossIntro"].includes(uiState) && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-[#050510]">
          <div
            className="text-2xl font-bold animate-pulse"
            style={{
              color: "#FFD700",
              fontFamily: "'Georgia', serif",
              textShadow: "0 0 20px rgba(255,215,0,0.5)",
            }}
          >
            Loading Game...
          </div>
        </div>
      )}
    </div>
  );
}
